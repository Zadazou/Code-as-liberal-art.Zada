x = 5
y= 10
if x > y:
    print("5 is greater than 10, not true")
else:
    print("BiBiGUGu")