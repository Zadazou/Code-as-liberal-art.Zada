score = 28
name = "Ora"
# writing some comments
# this is a comment
print(name)

name = "Zada"

print(name)
count = 0
print(count)
count = count + 1
print(count)

names = ["badah", "Beimnet", "Kristen", "Cate"]
numberofnames = len(names)
print(numberofnames)
print(names[1])
print(names[0]) #first thing refers to as "0"

for person in names:
    print(person)
